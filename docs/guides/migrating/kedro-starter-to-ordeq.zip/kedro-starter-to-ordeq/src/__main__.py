from ordeq_cli_runner import main

if __name__ == "__main__":
    main()
