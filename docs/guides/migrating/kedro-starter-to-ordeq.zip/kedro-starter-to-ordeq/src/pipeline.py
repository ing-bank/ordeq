from ordeq import node

from nodes import preprocess_companies, preprocess_shuttles
from catalog import companies, preprocessed_companies, shuttles, preprocessed_shuttles

spaceflights = {
    node(
        preprocess_companies,
        inputs=companies,
        outputs=preprocessed_companies,
    ),
    node(
        preprocess_shuttles,
        inputs=shuttles,
        outputs=preprocessed_shuttles,
    )
}
